import mysql.connector

# Connect to MySQL
def get_query():
    connection = mysql.connector.connect(
        host="localhost",
        port=3306,
        user="Your Username",
        password="Your Password",
        database="Database Name"
    )
   
    return connection 