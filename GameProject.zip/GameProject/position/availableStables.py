# stable_service.py

def get_player_location(conn, save_id): # Gets the player location from the DB
    cursor = conn.cursor(dictionary=True, buffered=True)

    query = """
        SELECT
            stables.id,
            stables.stable_name,
            cities.id AS city_id,
            cities.city_name
        FROM player_stats
        JOIN stables ON player_stats.location = stables.id
        JOIN cities ON stables.city_id = cities.id
        WHERE player_stats.save_id = %s
        LIMIT 1
    """

    cursor.execute(query, (save_id,))
    result = cursor.fetchone()
    cursor.close()

    return result


def get_available_stables(conn, save_id, max_distance=1000): # Gets the available stables from the DB and use Dijkstra Algorigthm to find the shortes distance between two cities

    # ----------------------------
    # STEP 1: Get player location
    # ----------------------------
    location = get_player_location(conn, save_id)

    if not location:
        return []

    start_city = location["city_id"]

    # ----------------------------
    # STEP 2: Load city graph
    # ----------------------------
    cursor = conn.cursor(dictionary=True, buffered=True)
    cursor.execute("SELECT city1_id, city2_id, distance FROM city_connections")
    rows = cursor.fetchall()
    cursor.close()

    graph = {}

    for row in rows:
        c1 = row["city1_id"]
        c2 = row["city2_id"]
        dist = float(row["distance"])

        if c1 not in graph:
            graph[c1] = []
        if c2 not in graph:
            graph[c2] = []

        graph[c1].append((c2, dist))
        graph[c2].append((c1, dist))

    # ----------------------------
    # STEP 3: Simple Dijkstra (no heap)
    # ----------------------------
    distances = {}
    visited = []

    # Initialize distances
    for city in graph:
        distances[city] = float("inf")

    distances[start_city] = 0

    while True:
        current_city = None
        current_min_distance = float("inf")

        # Find closest unvisited city
        for city in distances:
            if city not in visited and distances[city] < current_min_distance:
                current_city = city
                current_min_distance = distances[city]

        # Stop conditions
        if current_city is None:
            break

        if current_min_distance > max_distance:
            break

        visited.append(current_city)

        # Update neighbors
        for neighbor, weight in graph.get(current_city, []):
            new_distance = distances[current_city] + weight

            if new_distance < distances[neighbor]:
                distances[neighbor] = new_distance

    # ----------------------------
    # STEP 4: Collect reachable cities
    # ----------------------------
    reachable_cities = []

    for city, dist in distances.items():
        if 0 < dist <= max_distance:
            reachable_cities.append(city)

    if not reachable_cities:
        return []

    # ----------------------------
    # STEP 5: Fetch stables
    # ----------------------------
    cursor = conn.cursor(dictionary=True, buffered=True)

    format_strings = ",".join(["%s"] * len(reachable_cities))

    query = f"""
            SELECT 
                stables.id,
                stables.stable_name,
                stables.city_id,
                cities.city_name,
                nations.region
            FROM stables
            JOIN cities ON stables.city_id = cities.id
            JOIN nations ON cities.nation_id = nations.id
            WHERE stables.city_id IN ({format_strings})
        """

    cursor.execute(query, tuple(reachable_cities))
    stables = cursor.fetchall()
    cursor.close()

    return stables