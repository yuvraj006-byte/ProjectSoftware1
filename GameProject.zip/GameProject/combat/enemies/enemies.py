import json

def get_enemy(conn, region):
    cursor = conn.cursor(buffered=True)
    sql = """
        SELECT id,
               name,
               type,
               base_health,
               base_attack, 
               base_defence,
               total_health,
               xp_drop,
               attacks
        FROM enemies
        WHERE region = %s 
        AND name != 'Lilith'
        ORDER BY RAND()
        LIMIT 1;
    """

    cursor.execute(sql, (region,))
    enemy = cursor.fetchone()
    cursor.close()

    if not enemy:
        return None

    # Convert JSON string → Python dictionary
    attacks_dict = json.loads(enemy[8])

    # Get list of attack names
    attacks_list = list(attacks_dict.values())


    return {
        "id" : enemy[0],
        "name": enemy[1],
        "type": enemy[2],
        "base_health": enemy[3],
        "base_attack": enemy[4],
        "base_defence": enemy[5],
        "total_health": enemy[6],
        "xp_drop": enemy[7],
        "attack_type": attacks_list
    }